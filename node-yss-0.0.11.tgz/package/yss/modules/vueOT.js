class vueOT{

	constructor(){
		let cc = new otCl("vueOT");
		this.cl = function(){cc.doClFromArgs( arguments );  };
		this.callBack = -1;
	}

	load( fPath, targetIdObj, callBackOnDone ){

		this.cl("load",fPath, "to id DOM",targetIdObj);
		this.callBack = callBackOnDone;
		let mC = new mDoCmd();

		let nTmp = fPath.split("/");
		let loadName= nTmp[ nTmp.length-1 ].split(".")[0];
		this.cl("extract ","loadName",loadName);
		//this.vu

		mC.otdmArgs(
	    {'dfs':`/home/yoyo/Apps/oiyshTerminal/ySS_calibration/sites/test_vue/${fPath}`},
	    (d,r)=>{
	      //this.cl("got ls !!!");
	      //this.cl(d);
	      this.cl(`dfs`, "DONE","path", fPath);
	      let otO = this.vueSplit(loadName, targetIdObj, d);
	      //cp.vvPageViewObj.pageContent = cp.mdToHtml( d );
	    }
	  )
	}

	vueSplit( name, targetIdObj, vueRaw, onlyReturn = false ){
		let tr = {
			'name': name,
			'o': -1,
			'script': '',
			'template': '',
			'style': ''
		};


		this.cl("looking for template ...");
		let tTmp = vueRaw.split("<template>");
		tTmp = tTmp[1].split("</template>");
		if( tTmp.length == 2 ){
			this.cl("have IT!", tTmp[0]);
			tr['template'] = tTmp[0];
		}else{
			this.cl("don't have IT");
		}





	  this.cl("looking for style ...");
	  let cTmp = vueRaw.split("<style scoped>");
		if( cTmp.length == 1 ){
				this.cl('no style at all!')
		}else{
		  cTmp = cTmp[1].split("</style>");
		  if( cTmp.length == 2 ){
		    this.cl("have IT!", cTmp[0]);
				tr['style'] = cTmp[0];
		  }else{
		  	this.cl("don't have IT");
		  }
		}


		this.cl("looking for script ...");
		let sTmp = vueRaw.split("<script setup>");
		if( sTmp.length == 1 ){
			sTmp = vueRaw.split("<script>");
		}
		if( sTmp.length == 1 ){

			this.cl("Error have no <script> in file ....");
			let caStr = JSON.stringify({
				'template': tr['template']
			});


			let eInit = `function ${name}(){ Vue.createApp(${caStr});}`;
			sTmp = [
				eInit,
				sTmp[0]
			];

			this.cl("so new fake data is ....",sTmp);

			//return 0;
		}else{
			sTmp = sTmp[1].split("</script>");
		}
		if( sTmp.length > 1){
			this.cl('have IT!', sTmp[0]);
			let te = sTmp[0]+";\n";
			var o = -1;
			te+= `o = ${name};`;
			this.cl("so eval ...",te);
            try{
                eval(te);
            }catch(e){
                this.cl("Error *.vue "+e);
            }
			this.cl("o ...vue ?",o);

			tr['o'] = o;
			tr['script'] = sTmp[0];

		}else{
			this.cl("don't have IT");
		}



		this.cl("returning","---------------------",tr,"-----------------------------");
		//this.callBack( tr );
        if( onlyReturn == false ){

            this.cl("vComs","set","name",name)
            vComs[ name ] = tr;
            this.cl("cunnert","vComs","is",vComs);

            let vohw = tr['o']();


            setTimeout(()=>{
                $(`#${targetIdObj}`).html(`<div id="${name}">${tr['template']}</div>`);
                
                vohw.mount(`#${name}`);
                this.callBack("mounted");
            },1000);
            
        }else{
            return tr;
        }
	}

};

export { vueOT };